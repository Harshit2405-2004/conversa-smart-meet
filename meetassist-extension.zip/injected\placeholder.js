// This file is a placeholder for the injected directory
// Any JavaScript files that need to be injected into Google Meet pages
// should be placed in this directory and referenced in the manifest.json
// under web_accessible_resources.

console.log('MeetAssist: Injected scripts loaded'); 